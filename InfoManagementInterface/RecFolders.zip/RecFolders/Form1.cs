﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RecFolders
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            List<string> results = Find(txtFolderPath.Text, txtFileExtension.Text, txtString.Text);
            lbxResults.Items.Clear();
            foreach (string result in results)
                lbxResults.Items.Add(result);
        }

        private List<string> Find(string folderPath, string extension, string checkString)
        {
            List<string> filesInFolder = Directory
              .GetFiles(folderPath)
              .Where(x => x.ToLower().EndsWith(extension)).OrderByDescending(x => x).ToList();

            List<string> result = new List<string>();
            foreach (string file in filesInFolder)
            {
                int lineCount = 0;
                foreach (string line in File.ReadAllLines(file))
                {
                    lineCount++;
                    if (line.IndexOf(checkString) != -1)
                        result.Add("File:" + file + ", Line:" + lineCount + ", Position:" + line.IndexOf(checkString));
                }
            }

            return result;
        }
    }
}
